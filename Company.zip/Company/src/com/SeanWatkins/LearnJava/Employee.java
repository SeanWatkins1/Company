package com.SeanWatkins.LearnJava;

public class Employee {
    private String name;
    private Department department; // Aggregation relationship

    public Employee(String n, Department dept){
        this.name = n;
        this.department = dept;
    }

    public Department getDepartment(){
        return department;
    }

    @Override
    public String toString(){
        return name;
    }
}
