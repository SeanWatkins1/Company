package com.SeanWatkins.LearnJava;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class Main {

    public static void main(String[] args) {


        //Departments
        Department dept1 = new Department("Accounting");
        Department dept2 = new Department("IT");
        Department dept3 = new Department("Sales");
        Department dept4 = new Department("Marketing");

        //Employees
        Employee[] employees = {
                new Employee("Jane", dept1),
                new Employee("Mark", dept2),
                new Employee("Foster", dept2),
                new Employee("Brown", dept3),
                new Employee("Liam", dept4),
        };

        //Office
        Office off1 = new Office("Main");
        Office off2 = new Office("Left Wing");
        Office off3 = new Office("SubLevel");

        //Adding Offices to List
        List<Office> offices = new ArrayList<Office>();
        offices.add(off1);
        offices.add(off2);
        offices.add(off3);


        //Adding Departments to List
        List<Department> departments = new ArrayList<Department>();
        departments.add(dept1);
        departments.add(dept2);
        departments.add(dept3);
        departments.add(dept4);

        //Creating company and adding Departments
        Company enterprise1 = new Company("MicroTech", "3 Silicon Valley", departments, offices);

        //Print list of Departments for Company
        System.out.println("Departments: ");
        for (Department dep : enterprise1.getDepartments()) {
            System.out.println(dep.getName());


            //Print list of Offices for Company
            System.out.println("Offices: ");
            for (Office off : enterprise1.getOffices()) {
                System.out.println(off.getName());
            }

            //Print Employee info
            List<Employee> employeeList = Arrays.asList(employees);

            System.out.println("Employee list: ");
            employeeList.stream().forEach(System.out::println);


        }
    }
}




