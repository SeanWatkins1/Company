package com.SeanWatkins.LearnJava;

    public class Department {
        private String name;

        public Department(String n){
            this.name = n;
        }

        public String getName(){
            return name;
        }
}
