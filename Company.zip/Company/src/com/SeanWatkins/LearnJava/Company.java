package com.SeanWatkins.LearnJava;

    import java.util.List;

    public class Company {
        private String name;
        private String address;
        private final List<Department> departments; //composite relationship
        private final List<Office> offices;

        public Company(String n, String addr, List<Department> depts, List<Office> offi){
            this.name = n;
            this.address = addr;
            this.departments = depts;
            this.offices = offi;
        }

        public List<Department> getDepartments(){
            return departments;
        }

        public List<Office> getOffices(){
            return offices;
        }



        public String getName(){
            return name;
        }

        public String getAddress(){
            return address;
        }

    }
