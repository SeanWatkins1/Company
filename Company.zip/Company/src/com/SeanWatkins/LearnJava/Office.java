package com.SeanWatkins.LearnJava;

public class Office {
    private String name;

    public Office(String n){
        this.name = n;
    }

    public String getName(){
        return name;
    }
}

